
from flask import Flask, request, jsonify
import sqlite3
import random

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('kiwisoft.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            balance INTEGER,
            card_number TEXT
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    username = data['username']
    password = data['password']
    balance = 100
    card_number = f"{random.randint(1000,9999)} {random.randint(1000,9999)} {random.randint(1000,9999)}"
    conn = sqlite3.connect('kiwisoft.db')
    c = conn.cursor()
    try:
        c.execute('INSERT INTO users (username, password, balance, card_number) VALUES (?, ?, ?, ?)',
                  (username, password, balance, card_number))
        conn.commit()
    except sqlite3.IntegrityError:
        return jsonify({'status': 'error', 'message': 'User already exists'}), 400
    finally:
        conn.close()
    return jsonify({'status': 'ok', 'balance': balance, 'card_number': card_number})

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data['username']
    password = data['password']
    conn = sqlite3.connect('kiwisoft.db')
    c = conn.cursor()
    c.execute('SELECT balance, card_number FROM users WHERE username=? AND password=?', (username, password))
    user = c.fetchone()
    conn.close()
    if user:
        return jsonify({'status': 'ok', 'balance': user[0], 'card_number': user[1]})
    else:
        return jsonify({'status': 'error', 'message': 'Invalid credentials'}), 401

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
